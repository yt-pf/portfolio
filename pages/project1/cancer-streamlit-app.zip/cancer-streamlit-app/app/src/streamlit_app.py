from tempfile import NamedTemporaryFile

import lightgbm as lgb
import matplotlib.pyplot as plt
import pandas as pd
import plotly.express as px
import seaborn as sns
import streamlit as st
from sklearn import metrics
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from streamlit.components.v1 import html
from supertree import SuperTree

st.title("Breast Cancer データセットの特徴量エンジニアリング")

st.header("前提")

st.write("""以下は scikit‑learn に付属する Breast Cancer データセットを用いた分析である。\n
本分析では、機械学習アルゴリズムを用いて腫瘍が「良性」か「悪性」かを判別するモデルを構築し、特徴量の重要度や評価指標を検証する。""")


@st.cache_data
def load_data():
    dataset = load_breast_cancer()
    df = pd.DataFrame(dataset.data, columns=dataset.feature_names)
    df["target"] = dataset.target
    return dataset, df


dataset, df = load_data()

if st.checkbox("データテーブルの先頭（head）を表示"):
    st.subheader("データ概要")
    st.dataframe(df.head())

st.subheader("説明変数の表示")

st.write(dataset["feature_names"])

st.write("""翻訳すると以下のとおりである。説明変数では、何のデータを表しているのか掴みづらい。\n\n
平均半径,
平均テクスチャ,
平均周長,
平均面積,
平均平滑度,
平均コンパクトネス,
平均凹度,
平均凹点数,
平均対称性,
平均フラクタル次元,
半径誤差,
テクスチャ誤差,
周長誤差,
面積誤差,
滑らかさ誤差,
コンパクトネス誤差,
凹度誤差,
凹点誤差,
対称性誤差,
フラクタル次元誤差,
最悪半径,
最悪テクスチャ,
最悪周長,
最悪面積,
最悪滑らかさ,
最悪コンパクトネス,
最悪凹度,
最悪凹点,
最悪対称性,
最悪フラクタル次元
""")


st.subheader("目的変数のラベル")

st.write(dataset["target_names"])

st.write(
    "翻訳するとそれぞれ「悪性, 良性」となる。よって、腫瘍が悪性か良性かを分類することが目的だと推測できる。"
)


st.header("データの前処理")

st.subheader("欠損値の確認")

if st.checkbox("データテーブルを表示"):
    st.subheader("データ数")
    st.dataframe(df.describe().T["count"])
    st.subheader("欠損値数")
    st.dataframe(df.isnull().sum())

st.write("今回のデータセットに欠損値は存在しなかった。")

st.subheader("変数の相関を可視化")


# plotlyよりseabornのほうが見やすかったため、こちらを採用する
def plot_seaborn_heatmap():
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(
        df.corr(),
        annot=False,
        fmt=".2f",
        cmap="RdBu_r",
        vmin=-1,
        vmax=1,
        center=0,
        linewidths=0.5,
        ax=ax,
    )
    ax.set_title("Heatmap (Correlation)")
    return fig


st.pyplot(plot_seaborn_heatmap())

st.write(
    "色が濃い青に近い変数ほど、強い相関関係がある。よって、重要な特徴量だと推測できる。逆に、色が白に近い変数は、重要度が低いと判断できる。"
)

if st.checkbox("数値で確認する", key="df_corr"):
    st.write(df.corr())

st.subheader("外れ値の検索")

st.write("""データに外れ値がある場合、データ分析結果に影響する場合がある。数値で確認する他、散布図で確認する。\n
数値で確認する場合は、mean と median (50%) の差や、四分位範囲で判断するのが一般的だと思われる。\n
実際には、後述する通り、モデルに一度分析させてみる方が当たりをつけやすいと思われるが、今回は例として、無作為に選んだradius errorとmean areaの散布図を扱う。""")


if st.checkbox("要約統計量を数値で確認する", key="df_describe"):
    st.write(df.describe())

st.subheader("散布図")

numeric_columns = df.select_dtypes(include="number").columns.tolist()

default_x = "radius error"
default_y = "mean area"

x_col = st.selectbox(
    "X 軸に使用する列を選択してください",
    options=numeric_columns,
    index=numeric_columns.index(default_x) if default_x in numeric_columns else 0,
)

y_col = st.selectbox(
    "Y 軸に使用する列を選択してください",
    options=numeric_columns,
    index=numeric_columns.index(default_y) if default_y in numeric_columns else 1,
)


def plot_scatter(df, x_col, y_col):
    fig = px.scatter(
        df,
        x=x_col,
        y=y_col,
        title="Breast Cancer Dataset",
    )
    st.plotly_chart(fig, use_container_width=True)


plot_scatter(df, x_col, y_col)

st.write("""mean areaの値が2000以上のものを外れ値として除外してみる。""")

df_filtered = df[df["mean area"] < 2000]

plot_scatter(df_filtered, "radius error", "mean area")

st.write("除外前の相関係数")
st.write(df.corr()["mean area"]["radius error"])

st.write("除外後の相関係数")
st.write(df_filtered.corr()["mean area"]["radius error"])

st.write("""外れ値を除外した結果、相関係数が下がってしまった。\n
実務においては、この結果をどう読み解くかが肝心だと考える。""")

st.header("モデルの学習")

st.write(
    "ベンチマークとして、全てのデータを（加工やモデルのチューニングをせずに）そのまま入れて学習させると、以下の結果になる。（読み込みに時間がかかることがある）"
)

st.write("""なお、アルゴリズムはLightGBMによる勾配ブースティングを採用し、テストデータは30%とした。\n
LightGBMを採用した理由は以下の通り。\n
- 高速で精度が高い\n
- 欠損値の補完が不要\n
- 特徴のスケーリングが不要""")

# 説明変数と目的変数に分割する
# targetをy、それ以外をxに代入

y = df.iloc[:, -1:]
x = df.iloc[:, :-1]

# 訓練用データと評価用データに分割
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=1)

lgb_classifier = lgb.LGBMClassifier(
    objective="binary",
    num_class=1,
    max_depth=5,
    learning_rate=0.3,
    n_estimators=50,
    random_state=42,
    verbose=-1,
)

lgb_classifier.fit(x_train, y_train)

# 結果の予測
y_pred = lgb_classifier.predict(x_test)
# 予測確率を整数へ
y_pred = (y_pred > 0.5).astype(int)

# Accuracy scoreの出力
st.write("テストデータにおけるAccuracy scoreは以下の通り。")
st.write(metrics.accuracy_score(y_test, y_pred))


fig = lgb.plot_importance(
    lgb_classifier, figsize=(8, 4), max_num_features=5, importance_type="gain"
).figure
st.pyplot(fig)

st.write("""先述の通り、上のヒートマップにおける色の濃さと、特徴の重要度が類似しているように思える。\n
初期状態でも高い精度で正しく分類できているデータセットであるため、データクレンジングやチューニングする面白みには欠けるかもしれない。""")

st.header("決定木の可視化")

super_tree = SuperTree(
    lgb_classifier, x_test, y_test, x_test.columns.tolist(), dataset.target_names
)

with NamedTemporaryFile(suffix=".html") as f:
    super_tree.save_html(f.name, which_tree=0)
    html(f.read(), height=600)


st.write(
    "worst perimeterの値が大きなウェイトを占めている。値が境界値より低かったものほど良性であり、高いほど悪性であることが読み取れる。"
)

st.header("参考：クレンジングしたデータでの結果")

y = df_filtered.iloc[:, -1:]
x = df_filtered.iloc[:, :-1]

# DRYの原則に反しているが、今回はそのままにしておく

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3, random_state=1)

lgb_classifier.fit(x_train, y_train)

y_pred = lgb_classifier.predict(x_test)
y_pred = (y_pred > 0.5).astype(int)

st.write("テストデータにおけるAccuracy scoreは以下の通り。")
st.write(metrics.accuracy_score(y_test, y_pred))

st.write("""精度が下がってしまったので、単純に異常値を取り除けばよいというものではないことがわかる。\n
クレンジングするのであれば、worst perimeterの値を良性・悪性でグルーピングして、それぞれの四分位範囲で外れ値を除外する、などの案が考えられる。\n
やり方はほぼ同じのため、結果は割愛する。""")

fig = lgb.plot_importance(
    lgb_classifier, figsize=(8, 4), max_num_features=5, importance_type="gain"
).figure
st.pyplot(fig)
