BEGIN;

INSERT INTO regions (region_id, region)
SELECT DISTINCT
    region_id,
    region
FROM staging_jobchangers_raw
ORDER BY region_id;

INSERT INTO jobchangers (year, region_id, persons, note)
SELECT
    left(year, 4)::INTEGER,
    region_id,
    persons::INTEGER,
    note
FROM staging_jobchangers_raw;

CREATE INDEX idx_regions_region_id ON regions (region_id);
CREATE INDEX idx_jobchangers_year      ON jobchangers (year);
CREATE INDEX idx_jobchangers_region_id ON jobchangers (region_id);

COMMIT;

ROLLBACK;