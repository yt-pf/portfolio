#!/bin/bash
set -euo pipefail

DB_NAME="${POSTGRES_DB}"
DB_USER="${POSTGRES_USER}"
DB_PASSWORD="${POSTGRES_PASSWORD}"

psql -v ON_ERROR_STOP=1 \
    -U "$DB_USER" \
    -d "$DB_NAME" <<-EOSQL
    \copy staging_jobchangers_raw (year, region_id, region, persons, note) FROM '/docker-entrypoint-initdb.d/data/TimeSeriesResult_20250902111729107.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');
EOSQL
