CREATE TABLE IF NOT EXISTS staging_jobchangers_raw (
    id          SERIAL PRIMARY KEY,
    year        TEXT NOT NULL,
    region_id   CHAR(5) NOT NULL,
    region      TEXT NOT NULL,
    persons     TEXT,
    note        TEXT
);

CREATE TABLE IF NOT EXISTS regions (
    region_id   CHAR(5) PRIMARY KEY,
    region      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS jobchangers (
    id          SERIAL PRIMARY KEY,
    year        INTEGER,
    region_id   CHAR(5),
    persons     INTEGER,
    note        TEXT,
    CONSTRAINT fk_jobchangers_region
    FOREIGN KEY (region_id)
    REFERENCES regions (region_id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
);
